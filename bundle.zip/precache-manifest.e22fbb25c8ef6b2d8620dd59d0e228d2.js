self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "847fd4205fae09efd423327bf137ddaa",
    "url": "/index.html"
  },
  {
    "revision": "99130ec429c0acf0d74b",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "15759c18830a4aabc95c",
    "url": "/static/css/main.35e50a2a.chunk.css"
  },
  {
    "revision": "99130ec429c0acf0d74b",
    "url": "/static/js/2.ae5208d1.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.ae5208d1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15759c18830a4aabc95c",
    "url": "/static/js/main.bb6b29a2.chunk.js"
  },
  {
    "revision": "21f3ec35bc0153fa507c",
    "url": "/static/js/runtime-main.9ab2bbd9.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);